package com.cognizant.mohit.WishList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WishListApplicationTests {

	@Test
	void contextLoads() {
	}

}
