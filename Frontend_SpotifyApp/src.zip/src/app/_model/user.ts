import { Validators } from '@angular/forms';

export class User {
  username!: string;
  email!: string;
  firstName!: string;
  lastName!: string;
  password!: string;
  confirmPassword!: string;
  number!: string;
}

export const UserFormValidation = {
  username: ['', Validators.required],
  email: ['', [Validators.required, Validators.email]],
  firstName: ['', Validators.required],
  lastName: ['', Validators.required],
  password: ['', Validators.required],
  confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
  number: ['', Validators.pattern('^[0-9]*$')],
};
